
Go to this link and add ranger_base.dae to this folder

https://drive.google.com/file/d/1_UuPcv1ym_S12IVnqwNedrEESKhfejYF/view?usp=sharing
